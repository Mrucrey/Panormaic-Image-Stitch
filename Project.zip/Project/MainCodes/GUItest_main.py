import sys
from GUItest_ImageMerger import ImageMerger
from PyQt5 import sip
from PyQt5.QtWidgets import QApplication


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = ImageMerger()
    ImageMerger.clearImages(ex)  # 清空图片
    ex.show()
    sys.exit(app.exec_())
