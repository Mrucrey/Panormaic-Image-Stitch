from PyQt5.QtWidgets import QApplication, QMainWindow, QOpenGLWidget
from PyQt5.QtCore import QTimer,Qt
from PyQt5.QtGui import QImage
from OpenGL.GL import *
from OpenGL.GLU import *
from PIL import Image
import numpy as np
import sys

class CylinderRotationWindow(QOpenGLWidget):
    def __init__(self, qimage,parent=None):
        super(CylinderRotationWindow, self).__init__(parent)
        self.angle = 0
        self.qimage = self.downscaleImage(qimage)  # 调用函数降低图片分辨率

    def downscaleImage(self, qimage):
        # 假设我们要将图像缩小到原来的一半
        smaller_image = qimage.scaled(qimage.width() // 2, qimage.height() // 2, Qt.KeepAspectRatio)
        return smaller_image

    def initializeGL(self):
        glClearColor(0, 0, 0, 0)
        glEnable(GL_DEPTH_TEST)
        self.texture = self.loadTextureFromQImage(self.qimage)

    def loadTextureFromQImage(self, qimage):
        # 翻转图像以确保纹理不是上下颠倒的
        image = qimage.mirrored(False, True)  # False 表示不水平翻转，True 表示垂直翻转
        image = image.convertToFormat(QImage.Format_RGBA8888)
        img_data = image.constBits().asstring(image.width() * image.height() * 4)
        textureID = glGenTextures(1)
        glBindTexture(GL_TEXTURE_2D, textureID)
        
        # 设置纹理过滤参数
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
        
        # 创建纹理
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, image.width(), image.height(), 0, GL_RGBA, GL_UNSIGNED_BYTE, img_data)
        glGenerateMipmap(GL_TEXTURE_2D)
        return textureID

    def paintGL(self):
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        glEnable(GL_TEXTURE_2D)
        glBindTexture(GL_TEXTURE_2D, self.texture)
        glLoadIdentity()
        gluLookAt(3, 3, 3, 1, 1, 1.9, 0, 0, 1)

        glRotatef(self.angle, 0, 0, 1)
        self.angle += 0.1
        self.angle %= 360  # 防止溢出

        GLUquadric = gluNewQuadric()
        gluQuadricTexture(GLUquadric, GL_TRUE)
        gluCylinder(GLUquadric, 1, 1, 3, 32, 32)
        glDisable(GL_TEXTURE_2D)

        # 强制 OpenGL 重新绘制，更新画面
        self.update()

    def resizeGL(self, width, height):
        glViewport(0, 0, width, height)
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        gluPerspective(45, width / height, 1, 10)
        glMatrixMode(GL_MODELVIEW)

class MainWindow(QMainWindow):
    def __init__(self):
        super(MainWindow, self).__init__()
        self.openglWidget = CylinderRotationWindow(self)
        self.setCentralWidget(self.openglWidget)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.openglWidget.update)
        self.timer.start(100)

        self.resize(800, 600)  # 宽800px，高600px


