from PyQt5.QtWidgets import QWidget, QPushButton, QVBoxLayout, QLabel, QFileDialog, QScrollArea, QHBoxLayout,QSplitter,QMainWindow,QMessageBox
from PyQt5.QtGui import QImage, QIcon, QPixmap
from PyQt5.QtCore import Qt, QByteArray
from GUItest_stitch import Stitch
from GUItest_showCylinderRotation import CylinderRotationWindow
from PIL import Image
import os
import numpy as np

# 初始化一个空列表用于存储文件名
global file_names
file_names = []

class ImageMerger(QWidget):
    def __init__(self):
        # 存储导入的图片
        self.images = []  
        # 存储图像标签、删除按钮和文件名的对应关系
        self.image_elements = {}
        super().__init__()
        self.initUI()
        self.qimage = None  # 初始化QImage属性

    def initUI(self):
        # 设置窗口大小和最小大小
        self.resize(800, 600)  # 设置窗口大小为800x600
        self.setMinimumSize(600, 400)   # 设置最小大小为600x400

        # 创建 mergedImageLabel 属性并设置初始值
        self.mergedImageLabel = QLabel(self)
        self.mergedImageLabel.setGeometry(10, 10, 400, 300)
        self.mergedImageLabel.setAlignment(Qt.AlignCenter)

        # 设置窗口样式和图标
        self.setStyleSheet("QPushButton { background-color: #A3C1DA; color: black; padding: 10px 20px;border: none;border-radius: 5px;}")
        self.setStyleSheet("QPushButton:hover {background-color: #2980b9;}")
        self.setStyleSheet("QSplitter::handle {background-color: #ecf0f1;}")

        self.setWindowIcon(QIcon('1.jpg'))

        # 设置窗口标题
        self.setWindowTitle('图像拼接工具')

        # 创建主布局
        self.layout = QVBoxLayout(self)

        # 创建一个QSplitter用于分割上部和下部
        splitter = QSplitter(Qt.Vertical)

        # 上部布局
        top_layout = QHBoxLayout()
        
        # 创建打开图片按钮，并连接到槽函数 openImages
        self.open_button = QPushButton('打开图片')
        self.open_button.clicked.connect(self.openImages)
        top_layout.addWidget(self.open_button)

        # 创建拼接图片按钮，并连接到槽函数 mergeImages
        self.merge_button = QPushButton('拼接图片')
        self.merge_button.clicked.connect(self.mergeImages)
        top_layout.addWidget(self.merge_button)

        # 创建一个按钮来展示圆柱旋转图
        self.show_cylinder_button = QPushButton('展示圆柱旋转图')
        self.show_cylinder_button.clicked.connect(self.showCylinderRotation)
        top_layout.addWidget(self.show_cylinder_button)

        # 创建保存图片按钮，并连接到槽函数 saveImage
        self.save_button = QPushButton('保存图片')
        self.save_button.clicked.connect(self.saveImage)
        top_layout.addWidget(self.save_button)

        # 将上部布局添加到分割器
        top_widget = QWidget()
        top_widget.setLayout(top_layout)
        splitter.addWidget(top_widget)

        
         # 下部布局
        bottom_layout = QHBoxLayout()

        # 左侧布局用于显示导入的图片
        self.scrollArea = QScrollArea(self)  # 创建滚动区域
        self.imageContainer = QWidget()  # 创建一个容器放置图片标签
        self.imagesLayout = QVBoxLayout()  # 用于放置图片标签的布局

        # 设置图片容器的布局和滚动区域的属性
        self.imageContainer.setLayout(self.imagesLayout)
        self.scrollArea.setWidgetResizable(True)
        self.scrollArea.setWidget(self.imageContainer)

        bottom_layout.addWidget(self.scrollArea)

        # 右侧布局用于显示拼接好的图片
        self.result_scrollArea = QScrollArea(self)
        self.result_imageContainer = QWidget()
        self.result_imagesLayout = QVBoxLayout()

        # 设置图片容器的布局和滚动区域的属性
        self.result_imageContainer.setLayout(self.result_imagesLayout)
        self.result_scrollArea.setWidgetResizable(True)
        self.result_scrollArea.setWidget(self.result_imageContainer)

        bottom_layout.addWidget(self.result_scrollArea)

        # 将下部布局添加到分割器
        bottom_widget = QWidget()
        bottom_widget.setLayout(bottom_layout)
        splitter.addWidget(bottom_widget)

        # 将分割器添加到主布局
        self.layout.addWidget(splitter)

        # 设置窗口的初始位置和大小
        self.setGeometry(600, 300, 1200, 600)  # 设置窗口的初始大小

    def showCylinderRotation(self):
        if self.qimage is None:
        # 如果qimage为空，弹出警告对话框
            QMessageBox.warning(self, '警告', '还未拼接图片！')
        else:
            # 创建一个新窗口来展示圆柱旋转图
            self.cylinder_rotation_window = CylinderRotationWindow(self.qimage)
            self.cylinder_rotation_window.show()
    
    def openImages(self):
        global file_names  # 引用全局变量

        # 使用文件对话框获取用户选择的图像文件
        new_file_names, _ = QFileDialog.getOpenFileNames(None, '打开图片', '', '图像文件 (*.png *.jpg *.jpeg)')
        
        # 将新的文件名列表添加到全局变量中
        file_names.extend(new_file_names)
        
        # 遍历选中的图像文件
        for file_name in new_file_names:
            # 创建一个 QPixmap 对象并加载图像文件
            pixmap = QPixmap(file_name)
                
            # 创建一个 QLabel 用于显示图像，并设置图像大小（根据需要调整尺寸）
            label = QLabel(self)
            label.setPixmap(pixmap.scaled(400, 300, Qt.KeepAspectRatio))
                
            # 创建一个删除按钮
            delete_button = QPushButton('删除', self)
            delete_button.clicked.connect(lambda _, name=file_name: self.deleteImages(name))  # 连接删除按钮的槽函数

            # 创建一个水平布局，将图像标签和删除按钮放在一起
            image_layout = QHBoxLayout()
            image_layout.addWidget(label)
            image_layout.addWidget(delete_button)

            # 将水平布局添加到布局中，以在界面上显示图像和删除按钮
            self.imagesLayout.addLayout(image_layout)

            # 存储图像标签、删除按钮和文件名的对应关系
            self.image_elements[file_name] = (label, delete_button)

    def deleteImages(self, file_name):
        # 从布局中移除图像标签和删除按钮
        if file_name in self.image_elements:
            label, delete_button = self.image_elements[file_name]
            label.setParent(None)  # 从父布局中移除图像标签
            delete_button.setParent(None)  # 从父布局中移除删除按钮
            label.deleteLater()
            delete_button.deleteLater()

        # 从全局变量中移除文件名
        global file_names
        if file_name in file_names:
            file_names.remove(file_name)

    def clearMergedImage(self):
        # 移除旧的拼接图像
        if self.mergedImageLabel.pixmap() is not None:
            self.mergedImageLabel.setPixmap(QPixmap())  # 移除旧图像
        for i in reversed(range(self.result_imagesLayout.count())): 
            widget_to_remove = self.result_imagesLayout.itemAt(i).widget()
            if widget_to_remove is not None:
                widget_to_remove.setParent(None)

    def clearImages(self):
        # 清空存储的图像列表
        self.images = []

    def mergeImages(self):
        
        # 清除旧的拼接图像
        self.clearMergedImage()
        self.qimage = None

        # 打开图像文件并存储为图像对象列表
        images = [Image.open(x) for x in file_names]

        # 检查图片数量是否少于两张
        if len(file_names) < 2:
            QMessageBox.warning(self, "警告", "不能少于两张图片！")
            return  # 终止函数执行

        s = Stitch(images)
        s.leftshift()
        s.rightshift()
        s.crop_black_borders()
        
        # 将NumPy数组转换为QByteArray
        image_data = QByteArray(s.leftImage.tobytes())

        # 使用QByteArray传递图像数据
        qimage = QImage(image_data, s.leftImage.shape[1], s.leftImage.shape[0],3 * s.leftImage.shape[1],QImage.Format_RGB888)
       
        # 将拼接后的图像添加在 self.qimage中
        self.qimage = qimage

        # 创建一个 QLabel 用于显示拼接好的图片
        merged_image_label = QLabel(self)
        merged_image_label.setPixmap(QPixmap.fromImage(qimage).scaled(400, 300, Qt.KeepAspectRatio))

        # 将拼接后的图像添加在 self.mergedImageLabel 控件中
        self.mergedImageLabel = merged_image_label

        # # 更新拼接后的图像显示
        # self.mergedImageLabel.setPixmap(QPixmap.fromImage(self.qimage).scaled(400, 300, Qt.KeepAspectRatio))

        # 将拼接后的图片添加到右侧布局中
        self.result_imagesLayout.addWidget(merged_image_label)

    def saveImage(self):
        # 保存拼接后的图片到本地文件
        options = QFileDialog.Options()
        options |= QFileDialog.ReadOnly
        file_name, _ = QFileDialog.getSaveFileName(self, "保存图片", "", "Images (*.png *.jpg *.jpeg);;All Files (*)", options=options)

        if file_name:
            image_pixmap = self.mergedImageLabel.pixmap()
            image_pixmap.save(file_name)

