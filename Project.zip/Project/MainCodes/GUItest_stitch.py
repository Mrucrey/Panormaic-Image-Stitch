import numpy as np
import cv2
import sys
from GUItest_matchers import matchers
import time
import imutils

class Stitch:

    # 初步处理图像
    def __init__(self, images):
        # 将图像对象转换为 NumPy 数组
        images_np = [np.array(img) for img in images]
        # 加载图像并进行大小调整
        self.images = [cv2.resize(img, (480, 320)) for img in images_np]
        # 获取图像数量
        self.count = len(self.images)
        self.left_list, self.right_list, self.center_im = [], [], None
        # 创建用于图像匹配的matcher_obj对象
        self.matcher_obj = matchers()
        # 准备图像列表
        self.prepare_lists()

    # 准备图像列表
    def prepare_lists(self):
        # 检查 self.images 列表的长度
        print("Number of images:", len(self.images))
        # 计算中心图像的索引
        self.centerIdx = self.count / 2
        # 获取中心图像
        self.center_im = self.images[int(self.centerIdx)]
        # 检查索引将图像分为左侧和右侧
        for i in range(self.count):
            if (i <= self.centerIdx):
                self.left_list.append(self.images[i])
            else:
                self.right_list.append(self.images[i])

    # 实现左侧图像的平移和拼接
    def leftshift(self):

        # 获取第一张图像作为初始参考图像
        a = self.left_list[0]
        # 循环遍历左侧图像列表中的其他图像，从第二张开始
        for b in self.left_list[1:]:
            # 对齐图像
            H = self.matcher_obj.match(a, b, 'left')
            # 计算逆矩阵（用于将图像'b'映射回图像'a'的坐标系统，以便进行拼接）
            xh = np.linalg.inv(H)
            # 表示图像'a'在变换后的坐标系统中的尺寸
            ds = np.dot(xh, np.array([a.shape[1], a.shape[0], 1]))
            # 归一化
            ds = ds / ds[-1]
            # 表示原点在变换后的坐标系统中的位置
            f1 = np.dot(xh, np.array([0, 0, 1]))
            # 将'f1'的坐标归一化
            f1 = f1 / f1[-1]
            # 平移图像'a'使其能够与图像'b'对齐
            xh[0][-1] += abs(f1[0])
            xh[1][-1] += abs(f1[1])
            ds = np.dot(xh, np.array([a.shape[1], a.shape[0], 1]))
            # 计算偏移量，以确定图像拼接后的位置
            offsety = abs(int(f1[1]))
            offsetx = abs(int(f1[0]))
            # 计算拼接后的尺寸
            dsize = (int(ds[0]) + offsetx, int(ds[1]) + offsety)
            # 透视变换
            tmp = cv2.warpPerspective(a, xh, (a.shape[1] + offsetx, a.shape[0] + offsety))
            # 将图像'b'复制到拼接后的图像'tmp'上的正确位置
            tmp[offsety:offsety + b.shape[0], offsetx:offsetx + b.shape[1]] = b
            # 将拼接后的图像'tmp'赋值给变量'a'以便下一轮循环使用
            a = tmp

        # 存储拼接后的图像'tmp'
        self.leftImage = tmp

    # 平移和拼接右侧图像
    def rightshift(self):
        for each in self.right_list:
            # 对齐图像
            H = self.matcher_obj.match(self.leftImage, each, 'right')
            # 表示右侧图像在变换后的坐标系统中的尺寸和位置
            txyz = np.dot(H, np.array([each.shape[1], each.shape[0], 1]))
            txyz = txyz / txyz[-1]
            # 计算拼接后图像的尺寸
            dsize = (int(txyz[0]) + self.leftImage.shape[1], int(txyz[1]) + self.leftImage.shape[0])
            # 透视变换
            tmp = cv2.warpPerspective(each, H, dsize)
            tmp = self.mix_and_match(self.leftImage, tmp)
            self.leftImage = tmp

    # 混合和匹配
    def mix_and_match(self, leftImage, warpedImage):
        # 获取输入图像的尺寸
        i1y, i1x = leftImage.shape[:2]
        i2y, i2x = warpedImage.shape[:2]
        # 打印左上角像素的颜色值
        print(leftImage[-1, -1])
        # 查找图像中所有黑色像素的位置
        t = time.time()
        black_l = np.where(leftImage == np.array([0, 0, 0]))
        black_wi = np.where(warpedImage == np.array([0, 0, 0]))
        print(time.time() - t)
        print(black_l[-1])
        # 遍历图像的每个像素
        for i in range(0, i1x):
            for j in range(0, i1y):
                try:
                    # 如果左图和变换后图像的像素都是黑色，将变换后图像的像素设为黑色
                    if (np.array_equal(leftImage[j, i], np.array([0, 0, 0])) and
                        np.array_equal(warpedImage[j, i], np.array([0, 0, 0]))):
                        warpedImage[j, i] = [0, 0, 0]
                    else:
                        # 如果变换后图像的像素是黑色，用左图像的像素替换
                        if (np.array_equal(warpedImage[j, i], [0, 0, 0])):
                            warpedImage[j, i] = leftImage[j, i]
                        else:
                            # 如果左图像的像素不是黑色，用左图像的颜色替换变换后图像的颜色
                            if not np.array_equal(leftImage[j, i], [0, 0, 0]):
                                bw, gw, rw = warpedImage[j, i]
                                bl, gl, rl = leftImage[j, i]
                                warpedImage[j, i] = [bl, gl, rl]
                except:
                    pass

        # 返回处理后的变换后图像
        return warpedImage


    def trim_left(self):
        pass


    def showImage(self, string=None):
        if string == 'left':
            cv2.imshow("左图", self.leftImage)
        elif string == "right":
            cv2.imshow("右图", self.rightImage)
        cv2.waitKey()


    def crop_black_borders(self):
        # 添加黑色边框
        self.leftImage = cv2.copyMakeBorder(self.leftImage, 10, 10, 10, 10, cv2.BORDER_CONSTANT, (0, 0, 0))
        
        # 将图像转化为灰度图和二值图像
        gray = cv2.cvtColor(self.leftImage, cv2.COLOR_BGR2GRAY)
        thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY)[1]

        # 找到边框的轮廓
        cnts = cv2.findContours(thresh.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cnts = imutils.grab_contours(cnts)
        
        # 选择最大的轮廓
        c = max(cnts, key=cv2.contourArea)

        # 创建一个与图像大小相同的掩膜
        mask = np.zeros(thresh.shape, dtype="uint8")
        (x, y, w, h) = cv2.boundingRect(c)
        
        # 在掩膜上绘制矩形区域
        cv2.rectangle(mask, (x, y), (x + w, y + h), 255, -1)

        minRect = mask.copy()
        sub = mask.copy()

        # 使用腐蚀操作去除内部噪点
        while cv2.countNonZero(sub) > 0:
            minRect = cv2.erode(minRect, None)
            sub = cv2.subtract(minRect, thresh)

        # 找到最终的轮廓
        cnts = cv2.findContours(minRect.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cnts = imutils.grab_contours(cnts)
        c = max(cnts, key=cv2.contourArea)
        (x, y, w, h) = cv2.boundingRect(c)

        # 裁剪图像以去除黑色边框
        self.leftImage = self.leftImage[y:y + h, x:x + w]