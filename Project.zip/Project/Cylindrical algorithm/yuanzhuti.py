import cv2
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.colors import Normalize
from matplotlib.animation import FuncAnimation
import threading
import time
import sys

class TimeoutException(Exception):
    pass

def timeout_handler(timeout_minutes):
    time.sleep(timeout_minutes * 60)
    raise TimeoutException("程序运行时间超过设定的时间限制")

def update_cylinder(num, ax, x, y, z, image, cylinder_radius, cylinder_height):
    ax.cla()

    ax.set_xlim(-cylinder_radius, cylinder_radius)
    ax.set_ylim(-cylinder_radius, cylinder_radius)
    ax.set_zlim(0, cylinder_height)

    ax.invert_zaxis()
    ax.plot_surface(x, y, z, rstride=1, cstride=1, facecolors=image, shade=False)

    # 将视角调整到更左侧，扩大azim范围确保整个图像都能显示
    ax.view_init(elev=20, azim=num)

def update_sphere(num, ax, x, y, z, image, cylinder_radius, cylinder_height):
    ax.cla()

    theta = np.linspace(0, 2 * np.pi, image.shape[1])
    phi = np.linspace(0, np.pi, image.shape[0])
    theta, phi = np.meshgrid(theta, phi)

    x_sphere = cylinder_radius * np.sin(phi) * np.cos(theta)
    y_sphere = cylinder_radius * np.sin(phi) * np.sin(theta)
    z_sphere = cylinder_radius * np.cos(phi)

    ax.plot_surface(x_sphere, y_sphere, z_sphere, rstride=1, cstride=1, facecolors=image, shade=False)

    ax.set_xlim(-cylinder_radius, cylinder_radius)
    ax.set_ylim(-cylinder_radius, cylinder_radius)
    ax.set_zlim(-cylinder_radius, cylinder_radius)
    ax.view_init(elev=20, azim=num)

def create_rotating_animation(image_path, mapping_type, output_file, save_as_mp4=False, frames=None):
    try:
        image = cv2.imread(image_path)
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

        cylinder_radius = max(image.shape[0], image.shape[1]) / 2
        cylinder_height = image.shape[0]

        theta = np.linspace(0, 2 * np.pi, image.shape[1])
        z = np.linspace(0, cylinder_height, image.shape[0])
        theta, z = np.meshgrid(theta, z)

        x_cylinder = cylinder_radius * np.cos(theta)
        y_cylinder = cylinder_radius * np.sin(theta)

        norm = Normalize(image.min(), image.max())
        image = norm(image)

        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')

        initial_azim = 90
        ax.view_init(elev=20, azim=initial_azim)

        if mapping_type == 'cylinder':
            update_func = update_cylinder
            x, y, z = x_cylinder, y_cylinder, z
        elif mapping_type == 'sphere':
            update_func = update_sphere
            x, y, z = None, None, None  # Not needed for sphere mapping
        else:
            raise ValueError("无效的 mapping_type。请使用 'cylinder' 或 'sphere'。")

        animation = FuncAnimation(fig, update_func, frames=frames if frames is not None else np.arange(0, 360, 5),
                                  fargs=(ax, x, y, z, image, cylinder_radius, cylinder_height), interval=500)

        plt.show()  # 将 plt.show() 移动到这里

        animation.event_source.stop()  # 将此行移动到 plt.show() 之后

    except TimeoutException as e:
        print(f"程序超时：{e}")
    finally:
        if save_as_mp4:
            animation.save(output_file, writer='ffmpeg', fps=30)
        else:
            animation.save(output_file, writer='imagemagick')
        sys.exit(0)

# 生成圆柱体映射，限定动画转四圈
create_rotating_animation("D:/VSCode/Python/Digital Image Recognition/final/jiaqiu/img.png", mapping_type='cylinder', output_file="E:\\xyuan.gif", save_as_mp4=True, frames=np.arange(0, 360, 5))

